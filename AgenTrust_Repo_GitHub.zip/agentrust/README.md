# AgenTrust — página web y app (prototipo académico)

Prototipo del Smart Legal Contract para la cesantía comercial (Seminario III, UCEVA).
La carpeta `app/` ES la página web y la app instalable. No necesita servidor propio ni Claude para funcionar.

## A. Publicar la página web (gratis y permanente) — GitHub Pages
1. Cree una cuenta gratis en github.com y un repositorio **público** llamado `agentrust`.
2. En el repositorio: **Add file → Upload files** y suba TODO el contenido de esta carpeta
   (incluida la carpeta oculta `.github`; si no aparece en el repositorio, cree los dos archivos con
   **Add file → Create new file**, escribiendo el nombre `.github/workflows/pages.yml` y `.github/workflows/apk.yml` y pegando su contenido).
3. **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. Pestaña **Actions → Publicar web → Run workflow**. En un minuto la página queda en
   `https://SU-USUARIO.github.io/agentrust/` (esa dirección se la puede compartir a cualquiera).

Alternativa sin GitHub: arrastre la carpeta `app/` a https://app.netlify.com/drop (cree una cuenta gratis para que el sitio no se borre).

## B. Usarla como app en el celular (sin tienda)
- **Android (Chrome):** abra la dirección → botón «⬇ Instalar app» (o menú ⋮ → Instalar aplicación).
- **iPhone (Safari):** abra la dirección → Compartir → Añadir a pantalla de inicio.
Funciona sin internet y guarda el estado en el propio celular.

## C. Archivo APK para Android (sin instalar Android Studio)
1. En GitHub: pestaña **Actions → Construir APK → Run workflow**.
2. Cuando termine en verde, abra esa ejecución → **Artifacts → AgenTrust-apk** → descargue y descomprima.
3. Pase `app-debug.apk` al celular e instálelo (Android pide permitir instalar de «orígenes desconocidos»).
Es un APK de pruebas. Para Google Play se necesita un paquete firmado, que no está incluido.
(Para iPhone se requiere un Mac con Xcode y cuenta de desarrollador de Apple; la opción B ya cubre el iPhone.)

## Qué es y qué no es
Simula en el dispositivo la misma lógica del contrato inteligente (`AgenTrustCesantia.sol` va en el otro paquete).
No está conectada a una blockchain, no mueve dinero y no tiene oráculo ni custodia reales. No sustituye asesoría jurídica.
